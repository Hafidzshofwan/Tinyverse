"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { CSSProperties } from "react";
import { DAFTAR_KONDISI, KATEGORI_ALUR } from "@/shared/lib/alur/daftar";
import type { Kondisi } from "@/shared/lib/alur/daftar";
import { hitungObat } from "@/shared/lib/alur/dosis";
import { AlurIcon } from "@/shared/ui";
import {
  bacaPasienAktif,
  PASIEN_AKTIF_KEY,
  tambahKeRingkasan,
} from "@/shared/lib/alur/ringkasan-bridge";
import type {
  Alur,
  BlokKonten,
  Layar,
  Nada,
  Pasien,
  Setting,
} from "@/shared/lib/alur/tipe";

const LABEL_SETTING: Record<Setting, string> = {
  fktp: "FKTP / Fasilitas Primer",
  rs: "Rumah Sakit",
};

const LABEL_DERAJAT: Record<string, string> = {
  "ringan-sedang": "Ringan\u2013Sedang",
  berat: "Berat",
  ancaman: "Ancaman henti napas",
};

function usiaTeks(bln: number | null | undefined): string {
  if (bln == null) return "\u2013";
  const th = Math.floor(bln / 12);
  const sisa = bln % 12;
  if (th <= 0) return `${bln} bln`;
  return sisa ? `${th} th ${sisa} bln` : `${th} th`;
}

function gayaTombol(nada?: Nada): CSSProperties {
  if (nada === "bahaya")
    return {
      background: "linear-gradient(160deg,#e23a5e,#c01643)",
      color: "#fff",
      border: "none",
    };
  if (nada === "biasa")
    return {
      background: "var(--tv-putih)",
      color: "var(--tv-teks)",
      border: "1px solid var(--tv-line)",
    };
  return {};
}

function warnaDerajat(derajat?: string): string {
  if (derajat === "ringan-sedang") return "#1c7c54";
  if (derajat === "berat") return "#c9761a";
  if (derajat === "ancaman") return "#c01643";
  return "var(--tv-soft-teks)";
}

function warnaNada(nada?: Layar["nada"]): string {
  if (nada === "bahaya") return "#c01643";
  if (nada === "waspada") return "#c9761a";
  if (nada === "baik") return "#1c7c54";
  return "var(--tv-navy)";
}

function Timer({ menit }: { menit: number }) {
  const [sisa, setSisa] = useState<number | null>(null);

  useEffect(() => {
    if (sisa == null || sisa <= 0) return;
    const t = setInterval(
      () => setSisa((s) => (s == null ? s : Math.max(0, s - 1))),
      1000,
    );
    return () => clearInterval(t);
  }, [sisa]);

  if (sisa == null) {
    return (
      <button
        type="button"
        className="tv-btn"
        onClick={() => setSisa(menit * 60)}
      >
        ⏱️ Mulai timer nilai ulang ({menit} menit)
      </button>
    );
  }

  const mm = String(Math.floor(sisa / 60)).padStart(2, "0");
  const ss = String(sisa % 60).padStart(2, "0");
  const selesai = sisa <= 0;

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        flexWrap: "wrap",
      }}
    >
      <span
        style={{
          fontWeight: 800,
          fontSize: "1.5rem",
          fontVariantNumeric: "tabular-nums",
          color: selesai ? "#c01643" : "var(--tv-teks)",
        }}
      >
        {mm}:{ss}
      </span>
      {selesai && <span className="tv-warn">Waktunya nilai ulang.</span>}
      <button type="button" className="tv-btn" onClick={() => setSisa(null)}>
        Reset
      </button>
    </div>
  );
}

function RenderBlok({
  blok,
  pasien,
}: {
  blok: BlokKonten;
  pasien: Pasien | null;
}) {
  if (blok.jenis === "teks")
    return <p style={{ margin: "6px 0" }}>{blok.teks}</p>;

  if (blok.jenis === "poin")
    return (
      <ul style={{ margin: "6px 0", paddingLeft: 18 }}>
        {blok.poin.map((t, i) => (
          <li key={i} style={{ margin: "3px 0" }}>
            {t}
          </li>
        ))}
      </ul>
    );

  if (blok.jenis === "peringatan")
    return (
      <div className="tv-warn" style={{ margin: "8px 0" }}>
        ⚠️ {blok.teks}
      </div>
    );

  const d = hitungObat(blok.obatId, pasien ?? {});
  if (!d) return null;

  return (
    <div
      style={{
        border: "1px solid var(--tv-line)",
        borderRadius: 12,
        padding: "10px 12px",
        margin: "8px 0",
        background: "var(--tv-putih)",
      }}
    >
      <div style={{ fontWeight: 700 }}>
        💊 {d.def.nama}{" "}
        <span style={{ fontWeight: 400, color: "var(--tv-soft-teks)" }}>
          · {d.def.rute}
        </span>
      </div>
      <div style={{ marginTop: 2 }}>{d.hasil.ringkas}</div>
      {d.hasil.detail && (
        <div
          style={{
            fontSize: ".86rem",
            color: "var(--tv-soft-teks)",
            marginTop: 2,
          }}
        >
          {d.hasil.detail}
        </div>
      )}
      {d.hasil.peringatan && (
        <div className="tv-warn" style={{ marginTop: 4 }}>
          ⚠️ {d.hasil.peringatan}
        </div>
      )}
    </div>
  );
}

function komposisiRingkasan(
  alur: Alur,
  layar: Layar,
  setting: Setting,
  pasien: Pasien | null,
): string {
  const baris: string[] = [];
  if (!alur.tanpaSetting)
    baris.push(`Setting: ${LABEL_SETTING[setting]}`);
  if (
    pasien &&
    (pasien.nama || pasien.bb != null || pasien.usiaBulan != null)
  ) {
    baris.push(
      `Pasien: ${pasien.nama ?? "-"} \u00b7 BB ${pasien.bb ?? "-"} kg \u00b7 TB ${pasien.tb ?? "-"} cm \u00b7 Usia ${usiaTeks(pasien.usiaBulan)}`,
    );
  }
  baris.push("");
  for (const blok of layar.konten) {
    if (blok.jenis === "teks") baris.push(blok.teks);
    else if (blok.jenis === "poin")
      for (const p of blok.poin) baris.push(`\u2022 ${p}`);
    else if (blok.jenis === "peringatan") baris.push(`\u26a0 ${blok.teks}`);
    else {
      const d = hitungObat(blok.obatId, pasien ?? {});
      if (d)
        baris.push(`\u2022 ${d.def.nama} (${d.def.rute}): ${d.hasil.ringkas}`);
    }
  }
  baris.push("");
  baris.push(`Sumber: ${alur.sumber}`);
  return baris.join("\n");
}

export function AlurTatalaksanaPanel() {
  const [pasien, setPasien] = useState<Pasien | null>(null);
  const [kondisi, setKondisi] = useState<Kondisi | null>(null);
  const [alur, setAlur] = useState<Alur | null>(null);
  const [setting, setSetting] = useState<Setting | null>(null);
  const [stack, setStack] = useState<string[]>([]);
  const [toast, setToast] = useState<string | null>(null);
  const [bagan, setBagan] = useState(false);
  const activeStepRef = useRef<HTMLDivElement>(null);

  // Fokus kamera otomatis menyorot langkah selanjutnya saat opsi dipilih
  useEffect(() => {
    if (stack.length > 0 && activeStepRef.current) {
      activeStepRef.current.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  }, [stack]);

  useEffect(() => {
    setPasien(bacaPasienAktif());
    const muat = () => setPasien(bacaPasienAktif());
    const onStorage = (e: StorageEvent) => {
      if (!e.key || e.key === PASIEN_AKTIF_KEY) muat();
    };
    const onMsg = (e: MessageEvent) => {
      const d = e.data as { __tvPasien?: boolean } | null;
      if (d && d.__tvPasien) muat();
    };
    /*
     * WHY "tv-pasien-change" wajib ada di sini:
     *
     * Dua pendengar di bawah TIDAK PERNAH menyala di tab yang sama.
     * - "storage" menurut spesifikasi hanya dikirim ke tab LAIN, bukan ke tab
     *   yang melakukan penulisan.
     * - "message" hanya sampai bila pengirimnya iframe; penyiaran pusat
     *   mengirim postMessage khusus ke iframe.
     *
     * Akibatnya panel ini hanya ikut berubah setelah halaman dimuat ulang.
     * "tv-pasien-change" adalah satu-satunya sinyal intra-tab dari sumber
     * pusat, jadi tanpa baris ini dosis pada alur tatalaksana masih memakai
     * berat pasien SEBELUMNYA.
     */
    window.addEventListener("tv-pasien-change", muat);
    window.addEventListener("storage", onStorage);
    window.addEventListener("message", onMsg);
    return () => {
      window.removeEventListener("tv-pasien-change", muat);
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("message", onMsg);
    };
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2400);
    return () => clearTimeout(t);
  }, [toast]);

  const pilihKondisi = useCallback((k: Kondisi) => {
    setKondisi(k);
    setAlur(null);
    setBagan(false);
    k.muatAlur().then((data) => {
      setAlur(data);
      if (data.tanpaSetting) {
        setSetting("rs");
        setStack([data.mulai.rs]);
      } else {
        setSetting(null);
        setStack([]);
      }
    });
  }, []);

  const pilihSetting = useCallback(
    (s: Setting) => {
      if (!alur) return;
      setSetting(s);
      setStack([alur.mulai[s]]);
      setBagan(false);
    },
    [alur],
  );

  const pergi = useCallback(
    (tujuan: string) => setStack((st) => [...st, tujuan]),
    [],
  );
  const kembali = useCallback(() => {
    setStack((st) => {
      if (st.length > 1) return st.slice(0, -1);
      setSetting(null);
      return [];
    });
  }, []);
  const gantiSetting = useCallback(() => {
    setSetting(null);
    setStack([]);
    setBagan(false);
  }, []);
  const keDaftar = useCallback(() => {
    setKondisi(null);
    setAlur(null);
    setSetting(null);
    setStack([]);
    setBagan(false);
  }, []);

  // Deep-link dari pencarian global: buka penyakit langsung dari ?kondisi=<id> atau #tk=alur:<id>.
  useEffect(() => {
    function bukaDariHashAtauQuery() {
      if (typeof window === "undefined") return;

      // 1) Cek query param ?kondisi=dbd
      const params = new URLSearchParams(window.location.search);
      const kondisiParam = params.get("kondisi") || params.get("id");
      if (kondisiParam) {
        const k = DAFTAR_KONDISI.find((x) => x.id === kondisiParam && x.tersedia);
        if (k) {
          pilihKondisi(k);
          return;
        }
      }

      // 2) Cek hash #tk=alur:dbd
      const h = window.location.hash || "";
      const m = h.match(/[#&]tk=([^&]+)/);
      if (m) {
        const tk = decodeURIComponent(m[1] ?? "");
        if (tk.indexOf("alur:") === 0) {
          const id = tk.slice(5);
          const k = DAFTAR_KONDISI.find((x) => x.id === id && x.tersedia);
          if (k) {
            pilihKondisi(k);
            return;
          }
        }
      }

      // 3) Cek sessionStorage
      try {
        const rawTarget = sessionStorage.getItem("tv_search_target");
        if (rawTarget) {
          const parsed = JSON.parse(rawTarget);
          const anchor = String(parsed.anchor || "");
          if (anchor.startsWith("alur:")) {
            const id = anchor.replace("alur:", "");
            const k = DAFTAR_KONDISI.find((x) => x.id === id && x.tersedia);
            if (k) {
              pilihKondisi(k);
              return;
            }
          }
        }
      } catch (error) {
        console.warn(error);
      }
    }

    bukaDariHashAtauQuery();
    window.addEventListener("hashchange", bukaDariHashAtauQuery);
    return () => window.removeEventListener("hashchange", bukaDariHashAtauQuery);
  }, [pilihKondisi]);

  const punyaPasien = !!(
    pasien &&
    (pasien.nama || pasien.bb != null || pasien.usiaBulan != null)
  );
  const kartuPasien = (
    <div
      style={{
        border: "1px solid var(--tv-line)",
        borderRadius: 12,
        padding: "10px 12px",
        background: "var(--tv-putih)",
        marginBottom: 14,
      }}
    >
      <div
        style={{
          fontWeight: 700,
          fontSize: "1rem",
          color: "var(--tv-navy)",
          marginBottom: 2,
          display: "flex",
          alignItems: "center",
          gap: "8px",
        }}
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
          <rect width="24" height="24" rx="5" fill="#EEF2FF" />
          <circle cx="12" cy="8.5" r="3" fill="#4338CA" />
          <path d="M6 18.5C6 15.8 8.7 13.8 12 13.8C15.3 13.8 18 15.8 18 18.5" stroke="#4338CA" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
        <span>Profil Pasien</span>
      </div>
      {punyaPasien && pasien ? (
        <div style={{ fontSize: ".85rem" }}>
          {pasien.nama ?? "Tanpa nama"} · BB {pasien.bb ?? "\u2013"} kg · TB{" "}
          {pasien.tb ?? "\u2013"} cm · Usia {usiaTeks(pasien.usiaBulan)}
        </div>
      ) : (
        <div className="tv-warn" style={{ marginTop: 2 }}>
          Belum ada data pasien. Isi Profil Pasien agar dosis dihitung otomatis.
        </div>
      )}
    </div>
  );

  const disclaimer = (
    <div className="tv-disclaimer" style={{ marginTop: 12 }}>
      ⚠️ Alat bantu keputusan — bukan pengganti penilaian klinis. Verifikasi
      dosis sebelum pemberian.
    </div>
  );

  const toastEl = toast ? (
    <div
      style={{
        position: "fixed",
        left: "50%",
        bottom: 24,
        transform: "translateX(-50%)",
        background: "var(--tv-navy)",
        color: "#fff",
        padding: "10px 16px",
        borderRadius: 999,
        zIndex: 50,
        boxShadow: "0 6px 20px rgba(0,0,0,.18)",
      }}
    >
      {toast}
    </div>
  ) : null;

  // ===== 1) HALAMAN UTAMA: daftar penyakit =====
  if (!kondisi) {
    const grup = KATEGORI_ALUR.map((kat) => ({
      kat,
      items: DAFTAR_KONDISI.filter((k) => k.kategori === kat.id),
    })).filter((g) => g.items.length > 0);
    return (
      <div>
        {kartuPasien}
        <p style={{ margin: "0 0 16px", color: "var(--tv-soft-teks)" }}>
          Pilih kondisi untuk membuka alur tata laksana interaktif.
        </p>
        {grup.map(({ kat, items }) => (
          <section key={kat.id} className="tv-alur-kat-sec">
            <div
              className="tv-alur-kat"
              style={
                {
                  "--kat": kat.warna,
                  "--kat-lembut": kat.warnaLembut,
                  "--kat-id": kat.id,
                } as CSSProperties
              }
            >
              <span className="tv-alur-kat-ikon" style={{ display: "inline-flex", alignItems: "center", justifyContent: "center" }}>
                <AlurIcon id={kat.id} size={26} />
              </span>
              <span className="tv-alur-kat-nama">{kat.nama}</span>
              <span className="tv-alur-kat-garis" />
              <span className="tv-alur-kat-jml">{items.length}</span>
            </div>
            <div className="tv-alur-grid">
              {items.map((k) => (
                <button
                  key={k.id}
                  type="button"
                  className="tv-alur-kartu"
                  disabled={!k.tersedia}
                  onClick={() => k.tersedia && pilihKondisi(k)}
                  style={
                    {
                      "--kat": kat.warna,
                      "--kat-lembut": kat.warnaLembut,
                      "--kat-id": kat.id,
                    } as CSSProperties
                  }
                >
                  <span className="tv-alur-kartu-ikon" style={{ display: "inline-flex", alignItems: "center", justifyContent: "center" }}>
                    <AlurIcon id={k.id} size={36} />
                  </span>
                  <span className="tv-alur-kartu-teks">
                    <span className="tv-alur-kartu-judul">{k.nama}</span>
                    <span className="tv-alur-kartu-ringkas">{k.ringkas}</span>
                  </span>
                  <span className={"tv-alur-chip" + (k.tersedia ? " ada" : "")}>
                    {k.tersedia ? "Tersedia" : "Segera"}
                  </span>
                </button>
              ))}
            </div>
          </section>
        ))}
        {disclaimer}
        {toastEl}
      </div>
    );
  }

  // ===== LOADING: data alur kondisi ini sedang diunduh =====
  if (!alur) {
    return (
      <div>
        {kartuPasien}
        <button
          type="button"
          className="tv-btn"
          onClick={keDaftar}
          style={{ marginBottom: 12 }}
        >
          ← Daftar penyakit
        </button>
        <div className="tv-card">
          <div className="tv-card-title">Memuat alur...</div>
        </div>
        {toastEl}
      </div>
    );
  }

  // ===== 2) PILIH SETTING =====
  if (!setting) {
    return (
      <div>
        {kartuPasien}
        <button
          type="button"
          className="tv-btn"
          onClick={keDaftar}
          style={{ marginBottom: 12 }}
        >
          ← Daftar penyakit
        </button>
        <div className="tv-card">
          <div className="tv-card-title" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <AlurIcon id={kondisi.id} size={30} />
            <span>{kondisi.nama}</span>
          </div>
          <div className="tv-card-desc" style={{ marginTop: 3 }}>
            Pilih lokasi penanganan untuk memulai alur.
          </div>
          <div className="tv-stack" style={{ marginTop: 14 }}>
            <button
              type="button"
              className="tv-btn tv-btn-blok"
              onClick={() => pilihSetting("fktp")}
              style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect width="24" height="24" rx="5" fill="#EFF6FF"/><path d="M4 20H20M6 20V8L12 4L18 8V20M12 11V15M10 13H14" stroke="#2563EB" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
              <span>FKTP / Fasilitas Primer</span>
            </button>
            <button
              type="button"
              className="tv-btn tv-btn-blok"
              onClick={() => pilihSetting("rs")}
              style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect width="24" height="24" rx="5" fill="#FDF2F8"/><path d="M3 20H21M5 20V6L12 3L19 6V20M9 10H15M9 14H15" stroke="#D936A6" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/><path d="M12 10V14" stroke="#D936A6" strokeWidth="1.8" fill="none"/></svg>
              <span>Rumah Sakit</span>
            </button>
          </div>
          <div
            style={{
              fontSize: ".8rem",
              color: "var(--tv-soft-teks)",
              marginTop: 14,
            }}
          >
            Sumber: {alur.sumber}
          </div>
        </div>
        {toastEl}
      </div>
    );
  }

  // ===== 3) ALUR =====
  const kiniId = stack[stack.length - 1];
  const layar: Layar | undefined = kiniId
    ? alur.layar[kiniId]
    : undefined;
  const baganSrc = kondisi.bagan ? kondisi.bagan[setting] : undefined;

  if (!layar) {
    return (
      <div>
        <div className="tv-card">
          <div className="tv-card-title">Alur tidak ditemukan</div>
          <button
            type="button"
            className="tv-btn"
            style={{ marginTop: 12 }}
            onClick={keDaftar}
          >
            Kembali ke daftar
          </button>
        </div>
        {toastEl}
      </div>
    );
  }

  const gambarToggle: { src: string; keterangan?: string } | null = layar
    .gambarAlur?.toggle
    ? layar.gambarAlur
    : baganSrc
      ? { src: baganSrc, keterangan: undefined }
      : null;

  const tambah = () => {
    tambahKeRingkasan({
      title: `${kondisi.nama} \u2014 ${layar.judul}`,
      body: komposisiRingkasan(alur, layar, setting, pasien),
      source: `Alur ${kondisi.nama}`,
    });
    setToast("Ditambahkan ke Ringkasan Klinis \u2705");
  };

  return (
    <div>
      {kartuPasien}

      <div
        style={{
          display: "flex",
          gap: 8,
          alignItems: "center",
          flexWrap: "wrap",
          marginBottom: 12,
        }}
      >
        <button type="button" className="tv-btn" onClick={keDaftar}>
          ← Daftar
        </button>
        <span
          style={{
            fontSize: ".78rem",
            fontWeight: 700,
            padding: "4px 12px",
            borderRadius: 999,
            background: "var(--tv-accent-soft)",
            color: "var(--tv-navy)",
            display: "inline-flex",
            alignItems: "center",
            gap: "6px",
          }}
        >
          <AlurIcon id={kondisi.id} size={18} />
          <span>{kondisi.nama}</span>
          {!alur.tanpaSetting && ` \u00b7 ${LABEL_SETTING[setting]}`}
        </span>
        {stack.length > 1 && (
          <button type="button" className="tv-btn" onClick={kembali}>
            Kembali
          </button>
        )}
        {!alur.tanpaSetting && (
          <button type="button" className="tv-btn" onClick={gantiSetting}>
            Ganti setting
          </button>
        )}
      </div>

      {stack.length > 0 && (
        <>
          <style>{`
            @keyframes tvStepEntrance {
              0% {
                opacity: 0;
                transform: translateY(18px) scale(0.98);
              }
              100% {
                opacity: 1;
                transform: translateY(0) scale(1);
              }
            }
            .tv-step-card-animated {
              animation: tvStepEntrance 0.35s cubic-bezier(0.16, 1, 0.3, 1) forwards;
            }
          `}</style>

          <InteractiveDecisionTree
            stack={stack}
            alur={alur}
            onJumpToStep={(index) => setStack(stack.slice(0, index + 1))}
          />

          <ol className="tv-alur-stepper">
            {stack.map((id, i) => {
              const L = alur.layar[id];
              const aktif = i === stack.length - 1;
              const bisaKlik = i < stack.length - 1;
              return (
                <li
                  key={`${id}-${i}`}
                  className={"tv-alur-step" + (aktif ? " aktif" : "")}
                  style={{ "--nada": warnaNada(L?.nada) } as CSSProperties}
                >
                  <button
                    type="button"
                    className="tv-alur-step-btn"
                    disabled={!bisaKlik}
                    onClick={() => bisaKlik && setStack(stack.slice(0, i + 1))}
                    title={L?.judul}
                  >
                    <span className="tv-alur-step-node">{i + 1}</span>
                    <span className="tv-alur-step-lbl">
                      {L?.judul ?? "Langkah"}
                    </span>
                  </button>
                </li>
              );
            })}
          </ol>
        </>
      )}

      <div
        ref={activeStepRef}
        className="tv-card tv-step-card-animated"
        style={{ borderTop: `4px solid ${warnaNada(layar.nada)}`, scrollMarginTop: "80px" }}
      >
        {layar.derajat && (
          <div
            style={{
              fontSize: ".78rem",
              fontWeight: 800,
              color: warnaDerajat(layar.derajat),
              marginBottom: 4,
            }}
          >
            {LABEL_DERAJAT[layar.derajat] ?? layar.derajat}
          </div>
        )}
        <div className="tv-card-title">{layar.judul}</div>

        <div style={{ marginTop: 8 }}>
          {layar.konten.map((blok, i) => (
            <RenderBlok key={i} blok={blok} pasien={pasien} />
          ))}
        </div>

        {layar.timerMenit != null && (
          <div style={{ margin: "12px 0" }}>
            <Timer menit={layar.timerMenit} />
          </div>
        )}

        {layar.gambarAlur && !layar.gambarAlur.toggle && (
          <figure
            style={{
              margin: "16px 0 4px",
              border: "1px solid var(--tv-line)",
              borderRadius: 12,
              padding: 8,
              background: "var(--tv-putih)",
            }}
          >
            <img
              src={layar.gambarAlur.src}
              alt={layar.gambarAlur.keterangan ?? `Bagan alur ${kondisi.nama}`}
              loading="lazy"
              decoding="async"
              style={{
                width: "100%",
                height: "auto",
                borderRadius: 8,
                display: "block",
              }}
            />
            <figcaption
              style={{
                fontSize: ".78rem",
                color: "var(--tv-soft-teks)",
                marginTop: 6,
              }}
            >
              🖼️ {layar.gambarAlur.keterangan ?? "Bagan alur asli"} · Sumber:{" "}
              {alur.sumber}
            </figcaption>
          </figure>
        )}

        {layar.ringkasan && (
          <button
            type="button"
            className="tv-btn"
            style={{ marginTop: 8 }}
            onClick={tambah}
          >
            📄 Tambahkan ke Ringkasan
          </button>
        )}

        {layar.tombol.length > 0 && (
          <div className="tv-stack" style={{ marginTop: 16 }}>
            {layar.tombol.map((tb, i) => (
              <button
                key={i}
                type="button"
                className="tv-btn tv-btn-blok"
                style={gayaTombol(tb.nada)}
                onClick={() => pergi(tb.tujuan)}
              >
                {tb.label}
              </button>
            ))}
          </div>
        )}

        {layar.tombol.length === 0 && (
          <div
            style={{
              marginTop: 16,
              padding: "10px 12px",
              borderRadius: 10,
              background: "var(--tv-accent-soft)",
              fontSize: ".9rem",
            }}
          >
            ✅ Akhir alur untuk kondisi ini. Gunakan “Kembali” atau “← Daftar”
            untuk menelusuri cabang lain.
          </div>
        )}

        <div
          style={{
            fontSize: ".78rem",
            color: "var(--tv-soft-teks)",
            marginTop: 16,
          }}
        >
          Sumber: {alur.sumber}
        </div>
      </div>

      {gambarToggle && (
        <div style={{ marginTop: 12 }}>
          <button
            type="button"
            className="tv-btn"
            onClick={() => setBagan((b) => !b)}
          >
            🖼️ {bagan ? "Sembunyikan gambar alur" : "Gambar alur"}
          </button>
          {bagan && (
            <div
              style={{
                marginTop: 10,
                border: "1px solid var(--tv-line)",
                borderRadius: 12,
                padding: 8,
                background: "var(--tv-putih)",
              }}
            >
              <img
                src={gambarToggle.src}
                alt={
                  gambarToggle.keterangan ??
                  `Bagan ${kondisi.nama} \u2014 ${LABEL_SETTING[setting]}`
                }
                loading="lazy"
                decoding="async"
                style={{
                  width: "100%",
                  height: "auto",
                  borderRadius: 8,
                  display: "block",
                }}
              />
              <div
                style={{
                  fontSize: ".78rem",
                  color: "var(--tv-soft-teks)",
                  marginTop: 6,
                }}
              >
                {gambarToggle.keterangan ?? "Bagan asli"} — sumber:{" "}
                {alur.sumber}
              </div>
            </div>
          )}
        </div>
      )}

      {disclaimer}
      {toastEl}
    </div>
  );
}

function InteractiveDecisionTree({
  stack,
  alur,
  onJumpToStep,
}: {
  stack: string[];
  alur: Alur;
  onJumpToStep: (index: number) => void;
}) {
  return (
    <div
      className="tv-decision-tree-box"
      style={{
        background: "var(--tv-tree-bg, linear-gradient(180deg, #F8FAFC 0%, #F1F5F9 100%))",
        border: "1px solid var(--tv-tree-border, #CBD5E1)",
        borderRadius: 16,
        padding: "14px 16px",
        marginBottom: 16,
        boxShadow: "0 4px 12px rgba(15, 23, 42, 0.04)",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          marginBottom: 12,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span
            style={{
              background: "#2563EB",
              color: "#FFF",
              fontSize: "0.7rem",
              fontWeight: 800,
              padding: "2px 8px",
              borderRadius: 6,
              textTransform: "uppercase",
              letterSpacing: "0.5px",
            }}
          >
            Interactive Decision Tree
          </span>
          <h4
            className="tv-decision-tree-title"
            style={{
              margin: 0,
              fontSize: "0.92rem",
              fontWeight: 800,
              color: "var(--tv-teks, #0F172A)",
              fontFamily: "Fredoka, sans-serif",
            }}
          >
            Diagram Jalur Hidup Alur Klinis
          </h4>
        </div>
        <span
          className="tv-decision-tree-badge"
          style={{
            fontSize: "0.75rem",
            color: "var(--tv-soft-teks, #64748B)",
            fontWeight: 700,
            background: "var(--tv-accent-soft, #E2E8F0)",
            padding: "2px 8px",
            borderRadius: 999,
          }}
        >
          {stack.length} Langkah
        </span>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 10,
        }}
      >
        {stack.map((id, i) => {
          const L = alur.layar[id];
          const isLast = i === stack.length - 1;
          const nextId = stack[i + 1];
          let chosenOptionLabel: string | null = null;
          if (L && nextId) {
            const foundTb = L.tombol.find((t) => t.tujuan === nextId);
            if (foundTb) chosenOptionLabel = foundTb.label;
          }

          const nadaWarna = warnaNada(L?.nada);

          return (
            <div
              key={`${id}-${i}`}
              style={{
                display: "flex",
                flexDirection: "column",
                gap: 6,
              }}
            >
              <button
                type="button"
                className="tv-decision-tree-card"
                onClick={() => !isLast && onJumpToStep(i)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  background: isLast ? "var(--tv-putih, #FFFFFF)" : "var(--tv-tree-card-bg, rgba(255,255,255,0.85))",
                  border: isLast
                    ? `2px solid ${nadaWarna}`
                    : "1px solid var(--tv-line, #CBD5E1)",
                  borderLeft: `5px solid ${nadaWarna}`,
                  borderRadius: 12,
                  padding: "10px 14px",
                  cursor: isLast ? "default" : "pointer",
                  textAlign: "left",
                  boxShadow: isLast
                    ? `0 0 0 3px ${nadaWarna}22, 0 4px 12px rgba(0,0,0,0.06)`
                    : "0 1px 3px rgba(0,0,0,0.03)",
                  transition: "all 0.2s ease",
                  width: "100%",
                }}
              >
                <span
                  style={{
                    width: 28,
                    height: 28,
                    borderRadius: "50%",
                    background: isLast ? nadaWarna : "var(--tv-accent-soft, #E2E8F0)",
                    color: isLast ? "#FFFFFF" : "var(--tv-teks, #475569)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontWeight: 800,
                    fontSize: "0.82rem",
                    flexShrink: 0,
                  }}
                >
                  {i + 1}
                </span>

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontSize: "0.72rem",
                      color: "var(--tv-soft-teks, #64748B)",
                      fontWeight: 700,
                      textTransform: "uppercase",
                    }}
                  >
                    Langkah {i + 1}
                  </div>
                  <div
                    className="tv-decision-tree-step-judul"
                    style={{
                      fontSize: "0.88rem",
                      fontWeight: 700,
                      color: "var(--tv-teks, #0F172A)",
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {L?.judul ?? "Langkah"}
                  </div>
                </div>

                {isLast ? (
                  <span
                    style={{
                      background: `${nadaWarna}1A`,
                      color: nadaWarna,
                      fontWeight: 800,
                      fontSize: "0.72rem",
                      padding: "3px 10px",
                      borderRadius: 999,
                      border: `1px solid ${nadaWarna}44`,
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 4,
                    }}
                  >
                    <span
                      style={{
                        width: 6,
                        height: 6,
                        borderRadius: "50%",
                        background: nadaWarna,
                        display: "inline-block",
                      }}
                    />
                    Fokus Kamera
                  </span>
                ) : (
                  <span
                    style={{
                      fontSize: "0.72rem",
                      color: "#2563EB",
                      fontWeight: 700,
                      background: "#EFF6FF",
                      padding: "3px 8px",
                      borderRadius: 6,
                    }}
                  >
                    Lompat ke sini ↵
                  </span>
                )}
              </button>

              {!isLast && (
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    paddingLeft: 22,
                  }}
                >
                  <div
                    style={{
                      width: 2,
                      height: 16,
                      background: "#93C5FD",
                      borderRadius: 2,
                    }}
                  />
                  {chosenOptionLabel && (
                    <span
                      style={{
                        background: "#DBEAFE",
                        color: "#1E40AF",
                        fontSize: "0.74rem",
                        fontWeight: 700,
                        padding: "2px 8px",
                        borderRadius: 6,
                        border: "1px solid #BFDBFE",
                      }}
                    >
                      ➔ Opsi Terpilih: <b>{chosenOptionLabel}</b>
                    </span>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
