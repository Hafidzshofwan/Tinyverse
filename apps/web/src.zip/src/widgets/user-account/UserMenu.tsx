"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useAuth } from "./AuthProvider";
import { avatarProps } from "./avatar";
import { ProfileModal } from "./ProfileModal";
import { KopSuratModal } from "@/shared/ui/KopSuratModal";
import { ShieldUserIcon } from "@/shared/ui/icons/ShieldUserIcon";

function UserIcon({ size = 16, color = "currentColor" }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}

function KopSuratIcon({ size = 16, color = "currentColor" }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <path d="M12 11v6" />
      <path d="M9 14h6" />
    </svg>
  );
}

function LanggananIcon({ size = 16, color = "currentColor" }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="5" width="20" height="14" rx="2" />
      <path d="M2 10h20" />
      <path d="M6 15h4" />
    </svg>
  );
}

function LogOutIcon({ size = 16, color = "currentColor" }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
      <polyline points="16 17 21 12 16 7" />
      <line x1="21" y1="12" x2="9" y2="12" />
    </svg>
  );
}

/**
 * Tombol profil di header + dropdown. Menggantikan placeholder "Profil (segera)".
 * Setia dengan v17: avatar/inisial, nama, badge peran, menu Profil / Kelola
 * pengguna (admin) / Keluar.
 */
export function UserMenu() {
  const { profil, keluar } = useAuth();
  const [buka, setBuka] = useState(false);
  const [profilTampil, setProfilTampil] = useState(false);
  const [kopTampil, setKopTampil] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) {
        setBuka(false);
      }
    }
    document.addEventListener("click", onDocClick);
    return () => document.removeEventListener("click", onDocClick);
  }, []);

  if (!profil) return null;

  const admin = profil.role === "admin";
  const ava = avatarProps(profil.avatar, profil.nama);

  return (
    <div className="tv-user" ref={wrapRef}>
      <button
        type="button"
        className="tv-user-pill"
        onClick={(e) => {
          e.stopPropagation();
          setBuka((v) => !v);
        }}
      >
        <span
          className={"tv-user-av" + (ava.teks ? "" : " tv-user-av-foto")}
          style={ava.style}
          aria-hidden
        >
          {ava.teks}
        </span>
        <span className="tv-user-nama">{profil.nama || "Pengguna"}</span>
      </button>
      {buka && (
        <div className="tv-user-drop">
          <div className="tv-drop-info">
            <div className="n">{profil.nama || "Pengguna"}</div>
            <div className="e">{profil.email || ""}</div>
            <span className={"peran" + (admin ? " admin" : "")}>
              {admin ? "Admin" : "Pengguna"}
            </span>
          </div>
          <button
            className="tv-drop-item"
            onClick={() => {
              setBuka(false);
              setProfilTampil(true);
            }}
          >
            <UserIcon size={16} /> <span>Profil saya</span>
          </button>
          <button
            className="tv-drop-item"
            onClick={() => {
              setBuka(false);
              setKopTampil(true);
            }}
          >
            <KopSuratIcon size={16} /> <span>Kop Surat (PDF)</span>
          </button>
          <Link
            href="/langganan"
            className="tv-drop-item"
            style={{ textDecoration: "none" }}
            onClick={() => setBuka(false)}
          >
            <LanggananIcon size={16} /> <span>Langganan</span>
          </Link>
          {admin && (
            <Link
              href="/admin/pengguna"
              className="tv-drop-item"
              style={{ textDecoration: "none" }}
              onClick={() => setBuka(false)}
            >
              <ShieldUserIcon size={16} /> <span>Kelola pengguna</span>
            </Link>
          )}
          <button
            className="tv-drop-item"
            onClick={() => {
              setBuka(false);
              keluar();
            }}
          >
            <LogOutIcon size={16} /> <span>Keluar</span>
          </button>
        </div>
      )}
      {profilTampil && (
        <ProfileModal onTutup={() => setProfilTampil(false)} />
      )}
      <KopSuratModal isOpen={kopTampil} onClose={() => setKopTampil(false)} />
    </div>
  );
}
