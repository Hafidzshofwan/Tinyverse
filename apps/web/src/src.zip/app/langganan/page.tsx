import type { Metadata } from "next";
import { Suspense } from "react";

import { statusAksesSaatIni } from "@/server/entitlementServer";
import { riwayatPesanan } from "@/server/pesananRiwayat";
import { katalogTampil } from "@/server/planKatalog";
import { PROMO_LAUNCHING, promoSedangBerlaku } from "@/server/promoLaunching";
import { envMidtrans } from "@/server/env";
import { hitungPengingat } from "@/features/pengingat-langganan/pengingat";
import { FITUR_TERSEDIA } from "@/widgets/app-shell/nav-config";
import { LoadingAnimation } from "@/shared/ui";

import { LanggananClientView } from "./LanggananClientView";
import type { BarisRiwayat } from "./RiwayatPembayaran";
import gaya from "./langganan.module.css";

/* Admin SDK tidak bisa berjalan di Edge Runtime, sama seperti gerbang di
   app/preview/layout.tsx. */
export const runtime = "nodejs";
/* Halaman ini menampilkan status akun yang sedang masuk -- tidak boleh
   disajikan dari cache lintas pengguna. */
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Langganan",
  description:
    "Pilih paket langganan Tinyverse, pantau status akses, dan lihat riwayat pembayaran Anda.",
};

function rupiah(nilai: number): string {
  return "Rp" + nilai.toLocaleString("id-ID");
}

function tanggalIndo(iso: string): string {
  return new Date(iso).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

/** Memetakan status pesanan (StatusPesanan di @tinyverse/billing) ke kelas
 *  warna baris riwayat yang sudah ada di langganan.module.css. */
function kelasStatusPesanan(status: string): string {
  switch (status) {
    case "selesai":
    case "dibayar":
      return gaya.riwayatSelesai!;
    case "menunggu":
      return gaya.riwayatMenunggu!;
    default:
      // gagal, kedaluwarsa, dibatalkan
      return gaya.riwayatGagal!;
  }
}

function labelLencanaUntuk(status: "belum" | "aktif" | "kedaluwarsa", percobaan: boolean): string {
  if (status === "aktif") return percobaan ? "Trial" : "Aktif";
  if (status === "kedaluwarsa") return percobaan ? "Trial Habis" : "Kedaluwarsa";
  return "Belum Berlangganan";
}

/**
 * Isi sungguhan halaman /langganan -- dipisah dari default export di bawah
 * murni supaya bisa dibungkus <Suspense>.
 *
 * WHY dipisah: sebelumnya SELURUH halaman ini (termasuk katalog paket yang
 * sama untuk semua orang) menunggu dua permintaan Firestore BERURUTAN --
 * statusAksesSaatIni() lalu riwayatPesanan() -- selesai dulu sebelum satu
 * byte HTML pun terkirim ke peramban. Ditambah `dynamic = "force-dynamic"`
 * (tidak ada cache sama sekali), setiap kunjungan menanggung penuh biaya
 * dua round-trip itu. Di kondisi jaringan yang disimulasikan lebih lambat
 * (mobile), inilah yang membuat LCP meledak jauh di atas versi desktop --
 * bukan soal gambar atau CSS, murni HTML-nya belum mulai dikirim.
 *
 * Dengan Suspense, Next.js bisa langsung mengirim kerangka halaman +
 * fallback lebih dulu (lihat LoadingAnimation di bawah), lalu menyusulkan
 * konten sungguhan begitu kedua permintaan Firestore itu selesai -- pola
 * yang sama persis dengan PengingatSlot.tsx di layout akar.
 *
 * riwayatPesanan(accountId) SENGAJA tetap menunggu statusAksesSaatIni()
 * lebih dulu (bukan Promise.all): accountId hanya ada setelah panggilan
 * pertama selesai, jadi keduanya memang saling bergantung, tidak bisa
 * dijalankan paralel.
 */
async function LanggananContent() {
  const akses = await statusAksesSaatIni();
  const { masuk, accountId, entitlement, percobaan } = akses;

  const daftarPesananMentah =
    masuk && accountId ? await riwayatPesanan(accountId) : [];
  const daftarPesanan: BarisRiwayat[] = daftarPesananMentah.map((p) => ({
    id: p.id,
    nama: p.nama,
    tanggal: tanggalIndo(p.createdAt),
    harga: rupiah(p.hargaRupiah),
    labelStatus: p.labelStatus,
    kelasStatus: kelasStatusPesanan(p.status),
  }));

  const pengingat = hitungPengingat(
    {
      status: entitlement.status,
      berakhirPada: entitlement.berakhirPada,
      percobaan,
    },
    new Date().toISOString(),
  );
  const peringatan = pengingat
    ? {
        judul: pengingat.judul,
        teks: pengingat.pesan,
        kedaluwarsa: pengingat.nada === "berakhir",
      }
    : null;

  // Tampilan "Berlaku Sampai" memakai tanggal-bulan-tahun berbahasa
  // Indonesia, sama seperti tanggal riwayat pembayaran di bawahnya dan
  // seperti gerbang berbayar di app/preview/layout.tsx. Perhitungan sisa
  // hari & pengingat tetap memakai entitlement.berakhirPada mentah (ISO) di
  // atas -- hanya versi yang dikirim ke tampilan yang diformat di sini.
  const berakhirPadaTampil = entitlement.berakhirPada
    ? tanggalIndo(entitlement.berakhirPada)
    : null;

  const paketAktif = katalogTampil().filter((p) => p.aktif);
  const idPalingHemat =
    paketAktif.reduce<{ id: string; perHari: number } | null>((termurah, p) => {
      const perHari = p.hargaRupiah / p.durasiHari;
      if (!termurah || perHari < termurah.perHari) return { id: p.id, perHari };
      return termurah;
    }, null)?.id ?? null;

  // Dihitung sekali di server lalu dikirim sebagai prop tetap. Halaman ini
  // memakai `dynamic = "force-dynamic"`, jadi nilai ini tetap dievaluasi
  // ulang di setiap kunjungan -- promo akan padam sendiri begitu
  // PROMO_LAUNCHING.berakhir terlewati, tanpa deploy ulang.
  const promoAktifSekarang = promoSedangBerlaku();

  const { clientKey, urlSnapJs } = envMidtrans();

  return (
    <LanggananClientView
      masuk={masuk}
      status={entitlement.status}
      berakhirPada={berakhirPadaTampil}
      sisaHari={entitlement.sisaHari}
      percobaan={percobaan}
      labelLencana={labelLencanaUntuk(entitlement.status, percobaan)}
      peringatan={peringatan}
      daftarPesanan={daftarPesanan}
      paketAktif={paketAktif}
      idPalingHemat={idPalingHemat}
      labelTombol={masuk ? "Perpanjang" : "Beli Sekarang"}
      clientKey={clientKey}
      urlSnapJs={urlSnapJs}
      isiLangganan={FITUR_TERSEDIA.map((f) => ({ label: f.label, baru: f.baru, desc: f.desc }))}
      promoAktif={promoAktifSekarang}
      promoBerakhirPada={PROMO_LAUNCHING.berakhir}
      diskonPersen={PROMO_LAUNCHING.diskonPersen}
    />
  );
}

export default function LanggananPage() {
  return (
    <Suspense fallback={<LoadingAnimation message="Memuat halaman langganan..." />}>
      <LanggananContent />
    </Suspense>
  );
}
