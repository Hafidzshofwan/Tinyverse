export { BloodTab } from "./BloodTab";
