export { PalsTab } from "./PalsTab";
