export { PembelajaranPanel } from "./PembelajaranPanel";
