export { LabPanel } from "./LabPanel";
